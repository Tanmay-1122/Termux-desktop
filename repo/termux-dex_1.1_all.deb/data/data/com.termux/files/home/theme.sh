#!/data/data/com.termux/files/usr/bin/bash

# ============================================================
#   Termux Desktop — Theme Switcher
#   Applies XFCE themes: Dark (Dracula), Light, Retro
#   Can be run live (desktop must be running) or at setup
#   Usage: bash ~/theme.sh           ← interactive menu
#          bash ~/theme.sh --auto dark  ← apply silently
#   Repo : github.com/Tanmay-1122/Termux-desktop
# ============================================================

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC} $1"; }
info() { echo -e "  ${DIM}→${NC} $1"; }

# ─── Auto mode (called from setup.sh) ────────────────────────
AUTO_THEME=""
if [ "$1" = "--auto" ] && [ -n "$2" ]; then
    AUTO_THEME="$2"
fi

# ════════════════════════════════════════════════════════════
# Theme definitions
# Each theme sets:
#   THEME_NAME    — xfwm4 window manager theme
#   GTK_THEME     — GTK application theme
#   ICON_THEME    — icon pack
#   PANEL_BG      — panel background color (hex)
#   PANEL_FG      — panel text/icon color (hex)
#   FONT          — desktop font
#   WALLPAPER_CMD — command to set wallpaper color/gradient
#   TERM_BG       — xfce4-terminal background color
#   TERM_FG       — xfce4-terminal foreground color
#   TERM_PALETTE  — 16-color palette for xfce4-terminal
# ════════════════════════════════════════════════════════════

apply_dark_dracula() {
    echo ""
    echo -e "${CYAN}${BOLD}  Applying Dark (Dracula) Theme...${NC}"
    echo "  Deep purple-black background, vibrant color accents"
    echo ""

    # xfwm4 + GTK theme
    xfconf-query -c xfwm4 -p /general/theme -s "Default-hdpi" 2>/dev/null
    xfconf-query -c xsettings -p /Net/ThemeName -s "Adwaita-dark" 2>/dev/null

    # Panel colors (dark purple-black)
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-style -s 1 2>/dev/null
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-color \
        -s "#1e1f29ff" -t string 2>/dev/null

    # Desktop (Xfdesktop) background — solid dark purple
    xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/color-style \
        -s 0 2>/dev/null
    xfconf-query -c xfce4-desktop \
        -p /backdrop/screen0/monitor0/workspace0/rgba1 \
        -s "#1e1f29ff" -t string 2>/dev/null

    # xfce4-terminal Dracula palette
    if command -v xfconf-query &>/dev/null; then
        TERM_CONF="$HOME/.config/xfce4/terminal/terminalrc"
        if [ -f "$TERM_CONF" ] || mkdir -p "$(dirname "$TERM_CONF")" 2>/dev/null; then
            cat > "$TERM_CONF" << 'TERM_EOF'
[Configuration]
ColorForeground=#f8f8f2
ColorBackground=#1e1f29
ColorCursor=#f8f8f2
ColorPalette=#21222c;#ff5555;#50fa7b;#f1fa8c;#bd93f9;#ff79c6;#8be9fd;#f8f8f2;#6272a4;#ff6e6e;#69ff94;#ffffa5;#d6acff;#ff92df;#a4ffff;#ffffff
FontName=Monospace 11
MiscAlwaysShowTabs=FALSE
MiscBell=FALSE
MiscBellUrgent=FALSE
MiscBordersDefault=TRUE
MiscCursorBlinks=FALSE
MiscCursorShape=TERMINAL_CURSOR_SHAPE_BLOCK
MiscDefaultGeometry=100x30
MiscInheritGeometry=FALSE
MiscMenubarDefault=TRUE
MiscMouseAutohide=FALSE
MiscMouseWheelZoom=TRUE
MiscToolbarDefault=FALSE
MiscConfirmClose=TRUE
MiscCycleTabs=TRUE
MiscTabCloseButtons=TRUE
MiscTabCloseMiddleClick=TRUE
MiscTabPosition=GTK_POS_TOP
MiscHighlightUrls=TRUE
MiscMiddleClickOpensUri=FALSE
MiscCopyOnSelect=FALSE
MiscShowRelaunchDialog=TRUE
MiscRewrapOnResize=TRUE
MiscUseShiftArrowsToScroll=FALSE
MiscSlimTabs=FALSE
MiscNewTabAgreement=FALSE
MiscSearchDialogOpacity=100
MiscShowUnsafePasteDialog=TRUE
TERM_EOF
            ok "xfce4-terminal: Dracula palette applied"
        fi
    fi

    # Wallpaper — generate a solid dark purple PNG
    _set_wallpaper_color "1e1f29"

    ok "Dark (Dracula) theme applied"
    info "If the desktop is running, log out and back in to see all changes"
    info "Or run: xfce4-session-logout --logout"
}

apply_light_theme() {
    echo ""
    echo -e "${CYAN}${BOLD}  Applying Light Theme...${NC}"
    echo "  Clean white panels, minimal gray accents"
    echo ""

    xfconf-query -c xfwm4 -p /general/theme -s "Default" 2>/dev/null
    xfconf-query -c xsettings -p /Net/ThemeName -s "Adwaita" 2>/dev/null

    # Panel — light gray
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-style -s 1 2>/dev/null
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-color \
        -s "#f0f0f0ff" -t string 2>/dev/null

    # Desktop background — soft off-white
    xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/color-style \
        -s 0 2>/dev/null
    xfconf-query -c xfce4-desktop \
        -p /backdrop/screen0/monitor0/workspace0/rgba1 \
        -s "#e8e8e8ff" -t string 2>/dev/null

    # Terminal — light theme
    TERM_CONF="$HOME/.config/xfce4/terminal/terminalrc"
    mkdir -p "$(dirname "$TERM_CONF")" 2>/dev/null
    cat > "$TERM_CONF" << 'TERM_EOF'
[Configuration]
ColorForeground=#2d2d2d
ColorBackground=#ffffff
ColorCursor=#2d2d2d
ColorPalette=#2d2d2d;#cc3333;#3d9900;#9a8700;#3465a4;#75507b;#06989a;#d3d7cf;#555753;#ef2929;#8ae234;#fce94f;#729fcf;#ad7fa8;#34e2e2;#eeeeec
FontName=Monospace 11
MiscDefaultGeometry=100x30
MiscMenubarDefault=TRUE
MiscConfirmClose=TRUE
TERM_EOF

    _set_wallpaper_color "e8e8e8"

    ok "Light theme applied"
    info "Log out and back in to see all changes, or restart XFCE session"
}

apply_retro_theme() {
    echo ""
    echo -e "${CYAN}${BOLD}  Applying Retro Theme...${NC}"
    echo "  Old-school CRT look — amber text on pure black"
    echo ""

    xfconf-query -c xfwm4 -p /general/theme -s "Default-hdpi" 2>/dev/null
    xfconf-query -c xsettings -p /Net/ThemeName -s "Adwaita-dark" 2>/dev/null

    # Panel — pure black
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-style -s 1 2>/dev/null
    xfconf-query -c xfce4-panel -p /panels/panel-1/background-color \
        -s "#000000ff" -t string 2>/dev/null

    # Desktop — black
    xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/color-style \
        -s 0 2>/dev/null
    xfconf-query -c xfce4-desktop \
        -p /backdrop/screen0/monitor0/workspace0/rgba1 \
        -s "#000000ff" -t string 2>/dev/null

    # Terminal — amber on black (CRT classic)
    TERM_CONF="$HOME/.config/xfce4/terminal/terminalrc"
    mkdir -p "$(dirname "$TERM_CONF")" 2>/dev/null
    cat > "$TERM_CONF" << 'TERM_EOF'
[Configuration]
ColorForeground=#ffb300
ColorBackground=#000000
ColorCursor=#ffb300
ColorPalette=#1a1a00;#cc4400;#aaaa00;#ffb300;#aa6600;#cc7700;#ddaa00;#ffb300;#333300;#ff6600;#cccc00;#ffcc00;#cc8800;#ff9900;#ffdd00;#ffcc66
FontName=Monospace 12
MiscDefaultGeometry=100x30
MiscCursorShape=TERMINAL_CURSOR_SHAPE_BLOCK
MiscCursorBlinks=TRUE
MiscMenubarDefault=FALSE
TERM_EOF

    # Retro MOTD in .bashrc
    BASHRC="$HOME/.bashrc"
    # Only add once
    if ! grep -q "TERMUX_DESKTOP_RETRO" "$BASHRC" 2>/dev/null; then
        cat >> "$BASHRC" << 'RETRO_EOF'

# TERMUX_DESKTOP_RETRO — retro MOTD
echo ""
echo -e "\033[33m  ████████╗███████╗██████╗ ███╗   ███╗██╗   ██╗██╗  ██╗\033[0m"
echo -e "\033[33m     ██╔══╝██╔════╝██╔══██╗████╗ ████║██║   ██║╚██╗██╔╝\033[0m"
echo -e "\033[33m     ██║   █████╗  ██████╔╝██╔████╔██║██║   ██║ ╚███╔╝ \033[0m"
echo -e "\033[33m     ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║██║   ██║ ██╔██╗ \033[0m"
echo -e "\033[33m     ██║   ███████╗██║  ██║██║ ╚═╝ ██║╚██████╔╝██╔╝ ██╗\033[0m"
echo -e "\033[33m     ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═╝\033[0m"
echo -e "\033[33m              TERMUX DESKTOP  ///  READY\033[0m"
echo ""
RETRO_EOF
    fi

    _set_wallpaper_color "000000"

    ok "Retro (CRT Amber) theme applied"
    info "Terminal will show amber-on-black on next open"
    info "Log out and back in to apply to the full XFCE session"
}

# ════════════════════════════════════════════════════════════
# Helper — set solid wallpaper by creating a PNG via convert
# Falls back to just setting the xfdesktop color if ImageMagick
# is not installed
# ════════════════════════════════════════════════════════════
_set_wallpaper_color() {
    local hex="$1"
    local wallpaper_path="$HOME/.config/xfce4/wallpaper-${hex}.png"

    if command -v convert &>/dev/null; then
        convert -size 1920x1080 "xc:#${hex}" "$wallpaper_path" 2>/dev/null && {
            xfconf-query -c xfce4-desktop \
                -p /backdrop/screen0/monitor0/workspace0/last-image \
                -s "$wallpaper_path" 2>/dev/null
            xfconf-query -c xfce4-desktop \
                -p /backdrop/screen0/monitor0/workspace0/image-style \
                -s 1 2>/dev/null
            ok "Wallpaper set to #${hex}"
        }
    else
        info "ImageMagick not installed — wallpaper image not generated"
        info "Desktop background color has been set via xfconf"
    fi
}

# ════════════════════════════════════════════════════════════
# Auto mode (called from setup.sh --auto dark|light|retro)
# ════════════════════════════════════════════════════════════
if [ -n "$AUTO_THEME" ]; then
    case "$AUTO_THEME" in
        dark|dracula)  apply_dark_dracula ;;
        light)         apply_light_theme ;;
        retro)         apply_retro_theme ;;
        *)
            warn "Unknown theme '$AUTO_THEME' — using dark"
            apply_dark_dracula ;;
    esac
    exit 0
fi

# ════════════════════════════════════════════════════════════
# Interactive Menu
# ════════════════════════════════════════════════════════════
clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║       🎨  Termux Desktop — Theme Switcher       ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║                                                  ║"
echo "║   1) Dark (Dracula)   — purple-black, vivid     ║"
echo "║      Deep dark panels, vibrant terminal colors  ║"
echo "║                                                  ║"
echo "║   2) Light            — clean white panels      ║"
echo "║      Minimal gray UI, bright desktop            ║"
echo "║                                                  ║"
echo "║   3) Retro (CRT)      — amber on pure black     ║"
echo "║      Old-school terminal aesthetic              ║"
echo "║                                                  ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║   Note: Desktop session must be RUNNING to      ║"
echo "║   apply xfconf settings live.                   ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
read -rp "  Choose theme [1/2/3]: " CHOICE

case "$CHOICE" in
    1) apply_dark_dracula ;;
    2) apply_light_theme ;;
    3) apply_retro_theme ;;
    *)
        warn "Invalid choice — applying Dark (Dracula) as default"
        apply_dark_dracula ;;
esac

echo ""
echo -e "  ${GREEN}Theme change saved.${NC}"
echo "  Restart your XFCE session or run 'xfce4-panel -r' to see changes."
echo ""
echo "  Switch anytime: bash ~/theme.sh"
