#!/data/data/com.termux/files/usr/bin/bash

# ============================================================
#   Termux Desktop Launcher v2.0
#   Modes: A) Termux:X11  B) xRDP (WiFi/USB)  C) noVNC
#   Repo : github.com/Tanmay-1122/Termux-desktop
# ============================================================

# ── Cleanup old sessions ─────────────────────────────────────
echo "[*] Cleaning old sessions..."
pkill xrdp            2>/dev/null
pkill xrdp-sesman     2>/dev/null
pkill Xtigervnc       2>/dev/null
pkill Xvnc            2>/dev/null
pkill xfce4-session   2>/dev/null
pkill websockify      2>/dev/null
kill -9 $(pgrep -f "termux.x11") 2>/dev/null

vncserver -kill :1    2>/dev/null
rm -rf $PREFIX/tmp/.X*           2>/dev/null
rm -rf $PREFIX/tmp/.X11-unix/*   2>/dev/null
sleep 1

# ── Environment ──────────────────────────────────────────────
export PREFIX=/data/data/com.termux/files/usr
export HOME=/data/data/com.termux/files/home
export PATH=$PREFIX/bin:/system/bin:/system/xbin:$PATH

# ── Network detection ─────────────────────────────────────────
WIFI_IP=$(ifconfig wlan0 2>/dev/null | grep 'inet ' | awk '{print $2}')
USB_IP=""
USB_IFACE=""
for iface in rndis0 usb0 eth0; do
    IP=$(ifconfig "$iface" 2>/dev/null | grep 'inet ' | awk '{print $2}')
    if [ -n "$IP" ]; then
        USB_IP="$IP"
        USB_IFACE="$iface"
        break
    fi
done
BEST_IP="${WIFI_IP:-$USB_IP}"

# ── Optional: show dashboard before menu ──────────────────────
if [ "$1" = "--dashboard" ]; then
    bash "$HOME/dashboard.sh"
    exit 0
fi

# ════════════════════════════════════════════════════════════
# Launch Menu
# ════════════════════════════════════════════════════════════
clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║        🖥️   Termux Desktop  Launcher  v2        ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Network Status:                                 ║"
if [ -n "$USB_IP" ]; then
    printf "║   USB  (%-6s) : %-28s║\n" "$USB_IFACE" "$USB_IP"
else
    echo "║   USB            : Not detected                 ║"
fi
printf   "║   WiFi (wlan0)   : %-28s║\n" "${WIFI_IP:-Not detected}"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Select Display Mode:                            ║"
echo "║                                                  ║"
echo "║   A) Termux:X11  — Hardware-accelerated  ⚡      ║"
echo "║   B) xRDP        — Windows RDP (WiFi/USB) 🪟     ║"
echo "║   C) noVNC       — Any browser (WiFi)    🌐      ║"
echo "║                                                  ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Quick Tools:                                    ║"
echo "║   D) Dashboard   — system health               ║"
echo "║   T) Theme       — change desktop theme        ║"
echo "║   M) Manage Apps — install/remove apps         ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
if [ -n "$BEST_IP" ]; then
    echo "   💡 RDP address: $BEST_IP:3389"
    echo "   💡 noVNC URL  : http://$BEST_IP:6080/vnc.html"
else
    echo "   ⚠️  No network detected — Mode B and C may not work"
fi
echo ""
read -rp "   Enter choice [A/B/C/D/T/M]: " CHOICE
CHOICE=$(echo "$CHOICE" | tr '[:lower:]' '[:upper:]')

# ── Quick tool shortcuts ─────────────────────────────────────
case "$CHOICE" in
    D) exec bash "$HOME/dashboard.sh" ;;
    T) exec bash "$HOME/theme.sh" ;;
    M) exec bash "$HOME/manage-apps.sh" ;;
esac

# ════════════════════════════════════════════════════════════
# Shared helpers
# ════════════════════════════════════════════════════════════
setup_xsession() {
    export XDG_RUNTIME_DIR=$PREFIX/tmp/runtime-$UID
    mkdir -p "$XDG_RUNTIME_DIR"
    chmod 700 "$XDG_RUNTIME_DIR"

    cat > ~/.xsession << 'EOL'
export XDG_RUNTIME_DIR=$PREFIX/tmp/runtime-$UID
mkdir -p $XDG_RUNTIME_DIR
chmod 700 $XDG_RUNTIME_DIR
dbus-launch --exit-with-session xfce4-session
EOL
    chmod +x ~/.xsession
    echo "startxfce4" > ~/.Xclients
    chmod +x ~/.Xclients
}

configure_xrdp() {
    XRDP_INI="$PREFIX/etc/xrdp/xrdp.ini"
    [ ! -f "$XRDP_INI" ] && echo "[!] xrdp.ini not found" && return 1

    sed -i 's/^autorun=.*/autorun=Direct-VNC/' "$XRDP_INI"
    grep -q '^autorun=' "$XRDP_INI" || sed -i '/^\[Globals\]/a autorun=Direct-VNC' "$XRDP_INI"
    sed -i 's/^crypt_level=high/crypt_level=none/' "$XRDP_INI"

    if ! grep -q '\[Direct-VNC\]' "$XRDP_INI"; then
        cat >> "$XRDP_INI" << 'XRDPEOF'

[Direct-VNC]
name=NoLogin
lib=libvnc.so
username=na
password=na
ip=127.0.0.1
port=5901
XRDPEOF
    fi
}

start_vnc_server() {
    echo "[*] Starting VNC server on :1 (port 5901)..."
    vncserver :1 \
        -geometry 1366x768 \
        -depth 24 \
        -SecurityTypes None \
        -localhost no 2>/dev/null
    sleep 2

    if ! pgrep -f "Xvnc.*:1" > /dev/null && ! pgrep -f "Xtigervnc.*:1" > /dev/null; then
        echo "[!] VNC failed to start. Logs: ~/.vnc/"
        exit 1
    fi
    echo "[✓] VNC server running on port 5901"
}

# ════════════════════════════════════════════════════════════
# MODE A — Termux:X11
# ════════════════════════════════════════════════════════════
start_termux_x11() {
    echo ""
    echo "[*] Starting Termux:X11 mode..."

    pulseaudio --start \
        --load="module-native-protocol-tcp auth-ip-acl=127.0.0.1 auth-anonymous=1" \
        --exit-idle-time=-1 2>/dev/null

    export XDG_RUNTIME_DIR=${TMPDIR}
    termux-x11 :0 >/dev/null &
    sleep 3

    am start --user 0 \
        -n com.termux.x11/com.termux.x11.MainActivity > /dev/null 2>&1
    sleep 1

    export PULSE_SERVER=127.0.0.1
    export DISPLAY=:0

    echo ""
    echo "╔══════════════════════════════════════════════════╗"
    echo "║          ✅  TERMUX:X11  MODE  ACTIVE           ║"
    echo "╠══════════════════════════════════════════════════╣"
    echo "║   Termux:X11 app should open automatically      ║"
    echo "║   XFCE4 is launching — please wait a moment     ║"
    echo "║   Press Ctrl+C to stop                          ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""

    env DISPLAY=:0 dbus-launch --exit-with-session xfce4-session >/dev/null 2>&1 &
    wait
}

# ════════════════════════════════════════════════════════════
# MODE B — xRDP
# ════════════════════════════════════════════════════════════
start_xrdp() {
    echo ""
    echo "[*] Starting xRDP mode..."
    termux-wake-lock 2>/dev/null

    setup_xsession
    configure_xrdp
    start_vnc_server

    echo "[*] Launching XFCE4..."
    export DISPLAY=:1
    dbus-launch --exit-with-session xfce4-session > $PREFIX/tmp/xfce4.log 2>&1 &
    XFCE_PID=$!
    sleep 3

    echo "[*] Starting xRDP on port 3389..."
    xrdp-sesman > $PREFIX/tmp/xrdp-sesman.log 2>&1 &
    sleep 1
    xrdp > $PREFIX/tmp/xrdp.log 2>&1 &
    sleep 2

    if ! pgrep -x "xrdp" > /dev/null; then
        echo "[!] xRDP failed. Log:"
        cat $PREFIX/tmp/xrdp.log
        exit 1
    fi
    echo "[✓] xRDP running on port 3389"

    echo ""
    echo "╔══════════════════════════════════════════════════╗"
    echo "║           🪟  xRDP  MODE  ACTIVE               ║"
    echo "╠══════════════════════════════════════════════════╣"
    echo "║   Connect using Windows Remote Desktop (mstsc)  ║"
    echo "║                                                  ║"
    [ -n "$WIFI_IP" ] && printf "║   📶 WiFi  → %-34s║\n" "$WIFI_IP:3389"
    [ -n "$USB_IP"  ] && printf "║   🔌 USB   → %-34s║\n" "$USB_IP:3389"
    [ -z "$WIFI_IP" ] && [ -z "$USB_IP" ] && \
        echo "║   ⚠️  No IP detected — check connection         ║"
    echo "║                                                  ║"
    echo "║   💡 Leave username/password blank               ║"
    echo "║   💡 Press Ctrl+C to stop                        ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    wait $XFCE_PID
}

# ════════════════════════════════════════════════════════════
# MODE C — noVNC (browser access)
# ════════════════════════════════════════════════════════════
start_novnc() {
    echo ""
    echo "[*] Starting noVNC mode..."
    termux-wake-lock 2>/dev/null

    # Check websockify
    if ! command -v websockify &>/dev/null; then
        echo "[!] websockify not installed — installing now..."
        pkg install -y websockify || {
            echo "[!] Could not install websockify. Run: pkg install websockify"
            exit 1
        }
    fi

    # Check noVNC web client
    NOVNC_DIR="$HOME/noVNC"
    if [ ! -d "$NOVNC_DIR" ]; then
        echo "[*] Downloading noVNC web client..."
        if command -v wget &>/dev/null; then
            wget "https://github.com/novnc/noVNC/archive/refs/heads/master.zip" \
                -O /tmp/novnc.zip -q && \
            unzip -q /tmp/novnc.zip -d "$HOME" && \
            mv "$HOME/noVNC-master" "$NOVNC_DIR" && \
            rm /tmp/novnc.zip
        fi
    fi

    setup_xsession
    start_vnc_server

    echo "[*] Launching XFCE4..."
    export DISPLAY=:1
    dbus-launch --exit-with-session xfce4-session > $PREFIX/tmp/xfce4.log 2>&1 &
    XFCE_PID=$!
    sleep 3

    # Start websockify bridge
    echo "[*] Starting websockify on port 6080..."
    if [ -d "$NOVNC_DIR" ]; then
        websockify --web="$NOVNC_DIR" 6080 localhost:5901 > $PREFIX/tmp/websockify.log 2>&1 &
    else
        websockify 6080 localhost:5901 > $PREFIX/tmp/websockify.log 2>&1 &
    fi
    sleep 2

    echo ""
    echo "╔══════════════════════════════════════════════════╗"
    echo "║           🌐  noVNC  MODE  ACTIVE              ║"
    echo "╠══════════════════════════════════════════════════╣"
    echo "║   Open in any browser on your WiFi network:     ║"
    echo "║                                                  ║"
    [ -n "$WIFI_IP" ] && printf "║   📶 http://%-35s║\n" "$WIFI_IP:6080/vnc.html"
    [ -n "$USB_IP"  ] && printf "║   🔌 http://%-35s║\n" "$USB_IP:6080/vnc.html"
    [ -z "$WIFI_IP" ] && [ -z "$USB_IP" ] && \
        echo "║   ⚠️  No IP — run: ifconfig wlan0               ║"
    echo "║                                                  ║"
    echo "║   💡 Works on Windows, Mac, Linux, iOS, Android  ║"
    echo "║   💡 No app needed — just a browser              ║"
    echo "║   💡 Press Ctrl+C to stop                        ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""
    wait $XFCE_PID
}

# ════════════════════════════════════════════════════════════
# Route
# ════════════════════════════════════════════════════════════
case "$CHOICE" in
    A) start_termux_x11 ;;
    B) start_xrdp ;;
    C) start_novnc ;;
    *)
        echo ""
        echo "[!] Invalid choice — defaulting to Termux:X11..."
        sleep 1
        start_termux_x11
        ;;
esac
