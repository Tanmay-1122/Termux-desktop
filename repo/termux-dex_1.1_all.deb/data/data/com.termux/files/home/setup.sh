#!/data/data/com.termux/files/usr/bin/bash

# ============================================================
#   Termux Desktop — Setup Script v2.0
#   Run once after install.sh (or manually the first time)
#   Installs core packages + lets you pick apps via checklist
#   Repo : github.com/Tanmay-1122/Termux-desktop
# ============================================================

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

# ── Auto / non-interactive mode ────────────────────────────
# Usage:
#   bash setup.sh                  → interactive (asks questions)
#   bash setup.sh --auto            → non-interactive, "standard" app bundle
#   bash setup.sh --auto minimal    → core system only, no extra apps
#   bash setup.sh --auto full       → installs every app in the catalogue
AUTO_MODE=false
AUTO_PRESET="standard"
if [ "$1" = "--auto" ]; then
    AUTO_MODE=true
    [ -n "$2" ] && AUTO_PRESET="$2"
fi

# Default bundle used by `--auto` / `--auto standard`.
# Keep it useful but not huge; heavyweight GUI apps stay in the picker.
AUTO_STANDARD_PKGS=(git curl openssh htop nano micro tree unzip zip python nodejs mpv feh)

FAILED_REQUIRED=()
FAILED_OPTIONAL=()
STEP=0
TOTAL_STEPS=9

# ── Helpers ──────────────────────────────────────────────────
step() {
    STEP=$((STEP + 1))
    echo ""
    echo -e "${CYAN}${BOLD}[Step $STEP/$TOTAL_STEPS] $1${NC}"
    echo "────────────────────────────────────────"
}

ok()    { echo -e "  ${GREEN}✓${NC} $1"; }
warn()  { echo -e "  ${YELLOW}⚠${NC}  $1"; }
fail()  { echo -e "  ${RED}✗${NC} $1"; }
info()  { echo -e "  ${DIM}→${NC} $1"; }

# Progress bar display
# Usage: show_progress CURRENT TOTAL LABEL
show_progress() {
    local current=$1 total=$2 label=$3
    local percent=$(( current * 100 / total ))
    local filled=$(( percent * 30 / 100 ))
    local bar=""
    for ((i=0; i<30; i++)); do
        if [ $i -lt $filled ]; then bar="${bar}█"
        elif [ $i -eq $filled ]; then bar="${bar}▓"
        else bar="${bar}░"
        fi
    done
    printf "  \033[0;36m[%s]\033[0m \033[1m%3d%%\033[0m  %s\n" "$bar" "$percent" "$label"
}

# Install a package with progress display and retry logic
# Usage: safe_install PKG TIER PKG_NUM TOTAL_PKG DISPLAY_NAME
safe_install() {
    local pkg="$1"
    local tier="${2:-optional}"
    local num="${3:-1}"
    local total="${4:-1}"
    local display="${5:-$pkg}"

    show_progress "$num" "$total" "Installing $display..."

    if pkg install -y "$pkg" > $HOME/pkg_install.log 2>&1; then
        ok "$display installed"
        return 0
    fi

    if [ "$tier" = "required" ]; then
        warn "First attempt failed — retrying $display..."
        sleep 2
        if pkg install -y "$pkg" > $HOME/pkg_install.log 2>&1; then
            ok "$display installed (retry)"
            return 0
        fi
        fail "$display FAILED after retry"
        FAILED_REQUIRED+=("$pkg")
    else
        warn "$display skipped (optional)"
        FAILED_OPTIONAL+=("$pkg")
    fi
    return 1
}

pkg_installed() {
    dpkg -s "$1" >/dev/null 2>&1
}

pkg_available() {
    apt-cache show "$1" >/dev/null 2>&1
}

refresh_packages() {
    local log="${1:-$HOME/pkg_update.log}"
    pkg update -y > "$log" 2>&1
}

# Install a package group in one apt transaction. This is much faster than
# installing every package one by one, but falls back to individual packages
# so one bad optional package does not sink the whole run.
install_pkg_group() {
    local tier="$1"
    local label="$2"
    shift 2

    local pending=()
    local pkg

    for pkg in "$@"; do
        [ -z "$pkg" ] && continue

        if pkg_installed "$pkg"; then
            ok "$pkg already installed"
        elif pkg_available "$pkg"; then
            pending+=("$pkg")
        elif [ "$tier" = "required" ]; then
            fail "$pkg is not available in enabled repos"
            FAILED_REQUIRED+=("$pkg")
        else
            warn "$pkg is not available in enabled repos - skipped"
            FAILED_OPTIONAL+=("$pkg")
        fi
    done

    [ ${#pending[@]} -eq 0 ] && return 0

    show_progress 1 3 "Installing $label (${#pending[@]} package(s))..."
    if pkg install -y "${pending[@]}" > "$HOME/pkg_install.log" 2>&1; then
        ok "$label installed"
        return 0
    fi

    warn "$label batch install failed - refreshing indexes and retrying..."
    refresh_packages "$HOME/pkg_update_retry.log" || true
    show_progress 2 3 "Retrying $label..."
    if pkg install -y "${pending[@]}" > "$HOME/pkg_install.log" 2>&1; then
        ok "$label installed after retry"
        return 0
    fi

    warn "$label still failed - trying packages individually"
    local count=0
    local total=${#pending[@]}
    for pkg in "${pending[@]}"; do
        count=$((count + 1))
        safe_install "$pkg" "$tier" "$count" "$total" "$pkg"
    done
    show_progress 3 3 "Finished $label"
}

# ════════════════════════════════════════════════════════════
# APP CATALOGUE — Only packages verified to work in Termux
# Format: "pkg_name|display_name|category|description"
# ════════════════════════════════════════════════════════════

# Browsers
BROWSERS=(
    "firefox|Firefox|browser|Full desktop browser with GPU rendering"
    "chromium|Chromium|browser|Open-source Chrome base — good HTML5 support"
    "lynx|Lynx|browser|Lightweight terminal browser — fast and minimal"
    "w3m|w3m|browser|Terminal browser with inline image support"
)

# Code Editors
EDITORS=(
    "neovim|Neovim|editor|Modern Vim with LSP support — excellent in Termux"
    "gedit|Gedit|editor|GNOME text editor — clean GUI, good for beginners"
    "mousepad|Mousepad|editor|XFCE default editor — lightweight and fast"
    "nano|Nano|editor|Simple terminal editor — beginner friendly"
    "micro|Micro|editor|Modern terminal editor with mouse support"
)

# Programming Languages
LANGUAGES=(
    "python|Python 3|lang|Python interpreter + pip — essential for scripting"
    "nodejs|Node.js|lang|JavaScript runtime — includes npm"
    "ruby|Ruby|lang|Ruby interpreter + gem"
    "php|PHP|lang|PHP CLI — great for web dev practice"
    "golang|Go|lang|Google's Go language — fast compilation"
    "rust|Rust (rustup)|lang|Systems language — installs via rustup"
    "openjdk-17|Java 17 (OpenJDK)|lang|Java runtime + compiler"
    "lua54|Lua 5.4|lang|Lightweight scripting — used in Neovim plugins"
)

# Dev Tools
DEVTOOLS=(
    "git|Git|dev|Version control — essential for any dev workflow"
    "curl|cURL|dev|HTTP client — essential for APIs and downloads"
    "openssh|OpenSSH|dev|SSH server + client — remote access to your phone"
    "gh|GitHub CLI|dev|Manage GitHub repos from terminal"
    "jq|jq|dev|JSON processor — great for API work"
    "make|Make|dev|Build automation tool"
    "clang|Clang/LLVM|dev|C/C++ compiler suite"
    "cmake|CMake|dev|Cross-platform build system"
    "tmux|tmux|dev|Terminal multiplexer — multiple sessions in one window"
)

# Utilities
UTILITIES=(
    "htop|htop|util|Interactive process viewer — better than top"
    "neofetch|Neofetch|util|System info banner — great for screenshots"
    "thunar|Thunar|util|XFCE file manager — full GUI file browser"
    "galculator|Calculator|util|GTK calculator app"
    "mousepad|Mousepad (text editor)|util|Lightweight XFCE text editor"
    "xfce4-terminal|XFCE Terminal|util|Better terminal emulator for XFCE"
    "ranger|Ranger|util|Terminal file manager with vim keybindings"
    "tree|tree|util|Directory tree viewer"
    "unzip|unzip|util|Archive extraction tool"
    "zip|zip|util|Archive creation tool"
)

# Office / Productivity
OFFICE=(
    "libreoffice|LibreOffice|office|Full office suite (Writer, Calc, Impress)"
    "zathura|Zathura|office|Minimal PDF viewer — very lightweight"
    "evince|Evince|office|GNOME document viewer — PDF, EPUB, more"
    "xchm|xCHM|office|CHM help file viewer"
)

# Media
MEDIA=(
    "mpv|mpv|media|Lightweight video/audio player — hardware accelerated"
    "feh|feh|media|Fast image viewer — also great for wallpapers"
    "eog|Eye of GNOME|media|Full-featured image viewer"
    "ffmpeg|FFmpeg|media|Video/audio converter and processor"
)

# ════════════════════════════════════════════════════════════
# Interactive checklist function
# Usage: show_checklist "Category Name" ARRAY_NAME[@]
# Returns selected packages in SELECTED_PKGS array
# ════════════════════════════════════════════════════════════
SELECTED_PKGS=()

show_checklist() {
    local category_name="$1"
    shift
    local -n items=$1
    local selections=()
    local pkg_list=()
    local display_list=()
    local desc_list=()

    # Parse the catalogue entries
    for entry in "${items[@]}"; do
        IFS='|' read -r pkg display cat desc <<< "$entry"
        pkg_list+=("$pkg")
        display_list+=("$display")
        desc_list+=("$desc")
        selections+=(0)  # 0 = unchecked
    done

    local total=${#pkg_list[@]}
    local cursor=0

    while true; do
        clear
        echo ""
        echo -e "${CYAN}${BOLD}  ── $category_name ──${NC}"
        echo -e "  ${DIM}Space = toggle  │  Enter = confirm  │  A = select all  │  N = select none${NC}"
        echo ""

        for ((i=0; i<total; i++)); do
            local check="  "
            if [ "${selections[$i]}" -eq 1 ]; then
                check="${GREEN}✓${NC}"
            else
                check="○"
            fi

            if [ "$i" -eq "$cursor" ]; then
                echo -e "  ${CYAN}▶ [${check}]  ${BOLD}${display_list[$i]}${NC}"
                echo -e "       ${DIM}${desc_list[$i]}${NC}"
                echo ""
            else
                echo -e "    [${check}]  ${display_list[$i]}"
            fi
        done

        echo ""
        echo -e "  ${DIM}─────────────────────────────────────────${NC}"
        echo -e "  ${DIM}↑/k = up │ ↓/j = down │ Space = toggle │ Enter = done${NC}"

        # Read a single keypress
        IFS= read -rsn1 key 2>/dev/null

        case "$key" in
            $'\x1b')  # escape sequence (arrow keys)
                IFS= read -rsn1 -t 0.1 k2 2>/dev/null
                IFS= read -rsn1 -t 0.1 k3 2>/dev/null
                case "$k2$k3" in
                    '[A') [ $cursor -gt 0 ] && cursor=$((cursor - 1)) ;;  # Up
                    '[B') [ $cursor -lt $((total-1)) ] && cursor=$((cursor + 1)) ;;  # Down
                esac
                ;;
            'k'|'K') [ $cursor -gt 0 ] && cursor=$((cursor - 1)) ;;
            'j'|'J') [ $cursor -lt $((total-1)) ] && cursor=$((cursor + 1)) ;;
            ' ')  # Space — toggle
                if [ "${selections[$cursor]}" -eq 0 ]; then
                    selections[$cursor]=1
                else
                    selections[$cursor]=0
                fi
                ;;
            'a'|'A')  # Select all
                for ((i=0; i<total; i++)); do selections[$i]=1; done ;;
            'n'|'N')  # Select none
                for ((i=0; i<total; i++)); do selections[$i]=0; done ;;
            '')  # Enter — confirm
                break ;;
        esac
    done

    # Collect selected packages
    for ((i=0; i<total; i++)); do
        if [ "${selections[$i]}" -eq 1 ]; then
            SELECTED_PKGS+=("${pkg_list[$i]}")
        fi
    done
}

# ════════════════════════════════════════════════════════════
# BANNER
# ════════════════════════════════════════════════════════════
clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║     🛠️   Termux Desktop — Setup v2.0           ║"
echo "║     Smart install with progress tracking        ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
if $AUTO_MODE; then
    echo "  Auto mode: $AUTO_PRESET — no prompts, sit back."
else
    echo "  This sets up your full Linux desktop environment."
    echo "  You will choose which apps to install via a menu."
    echo ""
    read -rp "  Press ENTER to begin, or Ctrl+C to cancel... "
fi

# ════════════════════════════════════════════════════════════
# Step 1 — Update packages
# ════════════════════════════════════════════════════════════
step "Updating package lists"
show_progress 1 3 "Running pkg update..."
refresh_packages "$HOME/pkg_update.log" && ok "Package lists updated" || warn "Update had warnings (continuing)"
show_progress 2 3 "Skipping full pkg upgrade..."
info "Skipping full pkg upgrade for speed; run 'pkg upgrade' later if needed"
show_progress 3 3 "Package index ready"
ok "Package system ready"

# ════════════════════════════════════════════════════════════
# Step 2 — Add x11 repo
# ════════════════════════════════════════════════════════════
step "Adding x11 repository"
show_progress 1 2 "Installing x11-repo..."
install_pkg_group "required" "x11 repository" x11-repo
show_progress 2 2 "Refreshing package index..."
refresh_packages "$HOME/pkg_update_x11.log" || warn "x11 package refresh had warnings"
ok "x11 repository ready"

# ════════════════════════════════════════════════════════════
# Step 3 — Core system packages (required — no skipping)
# ════════════════════════════════════════════════════════════
step "Installing core system packages"
echo "  Installing the smallest reliable Termux:X11 desktop first."
echo ""

CORE_PKGS=(xfce4 termux-x11-nightly pulseaudio dbus wget unzip)
REMOTE_PKGS=(tigervnc xrdp websockify)
INSTALL_REMOTE=false

install_pkg_group "required" "core desktop" "${CORE_PKGS[@]}"

if $AUTO_MODE; then
    [ "$AUTO_PRESET" != "minimal" ] && INSTALL_REMOTE=true
else
    echo ""
    read -rp "  Install xRDP/noVNC remote desktop support too? [y/N]: " REMOTE_CHOICE
    [[ "$REMOTE_CHOICE" =~ ^[Yy]$ ]] && INSTALL_REMOTE=true
fi

if $INSTALL_REMOTE; then
    install_pkg_group "optional" "remote desktop support" "${REMOTE_PKGS[@]}"
else
    info "Skipping xRDP/noVNC packages for a faster setup"
fi

# ════════════════════════════════════════════════════════════
# Step 4 — App selection
# ════════════════════════════════════════════════════════════
step "Select apps to install"
SELECTED_PKGS=()

if $AUTO_MODE; then
    case "$AUTO_PRESET" in
        minimal)
            info "Minimal preset — core system only, no extra apps"
            ;;
        full)
            for arr in BROWSERS EDITORS LANGUAGES DEVTOOLS UTILITIES OFFICE MEDIA; do
                declare -n items="$arr"
                for entry in "${items[@]}"; do
                    IFS='|' read -r pkg _ <<< "$entry"
                    SELECTED_PKGS+=("$pkg")
                done
                unset -n items
            done
            info "Full preset — installing every catalogue app (this takes a while)"
            ;;
        *)
            SELECTED_PKGS=("${AUTO_STANDARD_PKGS[@]}")
            info "Standard preset — installing a sensible default bundle"
            ;;
    esac
else
    echo ""
    echo "  You will now select apps from each category."
    echo "  Use arrow keys to navigate, Space to toggle, Enter to confirm."
    echo ""
    echo -e "  ${YELLOW}Note: Only Termux-compatible apps are listed.${NC}"
    echo ""
    read -rp "  Press ENTER to open the app selector... "

    # Category selection menu first
    clear
    echo ""
    echo -e "${CYAN}${BOLD}  ── App Categories ──${NC}"
    echo "  Which categories do you want to browse?"
    echo ""
    echo "  1) Browsers"
    echo "  2) Code Editors"
    echo "  3) Programming Languages"
    echo "  4) Dev Tools (Git, SSH, etc.)"
    echo "  5) Utilities (htop, file manager, etc.)"
    echo "  6) Office / Productivity"
    echo "  7) Media (video player, image viewer)"
    echo "  A) All categories"
    echo "  S) Skip — don't install any apps now"
    echo "  (You can always run manage-apps.sh later)"
    echo ""
    read -rp "  Enter categories [e.g. 1 2 4 or A]: " CAT_CHOICE

    # Determine which categories to show
    DO_BROWSERS=false DO_EDITORS=false DO_LANGS=false
    DO_DEV=false DO_UTIL=false DO_OFFICE=false DO_MEDIA=false

    if echo "$CAT_CHOICE" | grep -qi 'a'; then
        DO_BROWSERS=true; DO_EDITORS=true; DO_LANGS=true
        DO_DEV=true; DO_UTIL=true; DO_OFFICE=true; DO_MEDIA=true
    elif echo "$CAT_CHOICE" | grep -qi 's'; then
        info "Skipping app selection — run manage-apps.sh later to install apps"
    else
        echo "$CAT_CHOICE" | grep -q '1' && DO_BROWSERS=true
        echo "$CAT_CHOICE" | grep -q '2' && DO_EDITORS=true
        echo "$CAT_CHOICE" | grep -q '3' && DO_LANGS=true
        echo "$CAT_CHOICE" | grep -q '4' && DO_DEV=true
        echo "$CAT_CHOICE" | grep -q '5' && DO_UTIL=true
        echo "$CAT_CHOICE" | grep -q '6' && DO_OFFICE=true
        echo "$CAT_CHOICE" | grep -q '7' && DO_MEDIA=true
    fi

    # Show checklists for selected categories
    $DO_BROWSERS && show_checklist "Browsers"              BROWSERS
    $DO_EDITORS  && show_checklist "Code Editors"          EDITORS
    $DO_LANGS    && show_checklist "Programming Languages" LANGUAGES
    $DO_DEV      && show_checklist "Dev Tools"             DEVTOOLS
    $DO_UTIL     && show_checklist "Utilities"             UTILITIES
    $DO_OFFICE   && show_checklist "Office / Productivity" OFFICE
    $DO_MEDIA    && show_checklist "Media"                 MEDIA
fi

# Install selected apps
if [ ${#SELECTED_PKGS[@]} -gt 0 ]; then
    # Remove duplicates
    SELECTED_PKGS=($(printf '%s\n' "${SELECTED_PKGS[@]}" | sort -u))

    clear
    step "Installing selected apps"
    echo "  ${#SELECTED_PKGS[@]} package(s) selected to install:"
    for pkg in "${SELECTED_PKGS[@]}"; do echo "   • $pkg"; done
    echo ""

    install_pkg_group "optional" "selected apps" "${SELECTED_PKGS[@]}"
else
    info "No apps selected — skipping app install"
fi

# ════════════════════════════════════════════════════════════
# Step 6 — Configure xRDP
# ════════════════════════════════════════════════════════════
step "Configuring xRDP for direct VNC passthrough"
XRDP_INI="$PREFIX/etc/xrdp/xrdp.ini"

if [ -f "$XRDP_INI" ]; then
    sed -i 's/^autorun=.*/autorun=Direct-VNC/' "$XRDP_INI"
    grep -q '^autorun=' "$XRDP_INI" || \
        sed -i '/^\[Globals\]/a autorun=Direct-VNC' "$XRDP_INI"
    sed -i 's/^crypt_level=high/crypt_level=none/' "$XRDP_INI"

    if ! grep -q '\[Direct-VNC\]' "$XRDP_INI"; then
        cat >> "$XRDP_INI" << 'XRDPEOF'

[Direct-VNC]
name=NoLogin
lib=libvnc.so
username=na
password=na
ip=127.0.0.1
port=5901
XRDPEOF
        ok "Direct-VNC section added"
    else
        ok "Direct-VNC already configured"
    fi
    ok "xRDP configured (passwordless VNC passthrough)"
else
    warn "xrdp.ini not found — xRDP may not be installed"
fi

# ════════════════════════════════════════════════════════════
# Step 7 — Set up Termux:Widget shortcut
# ════════════════════════════════════════════════════════════
step "Creating home-screen widget shortcut"
SHORTCUTS_DIR="$HOME/.shortcuts"
mkdir -p "$SHORTCUTS_DIR"
chmod 700 "$SHORTCUTS_DIR"

WIDGET_SCRIPT="$SHORTCUTS_DIR/Start Desktop.sh"
cat > "$WIDGET_SCRIPT" << 'WIDGET_EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME"
bash "$HOME/start-desktop.sh"
WIDGET_EOF
chmod +x "$WIDGET_SCRIPT"
ok "Widget script: ~/.shortcuts/Start Desktop.sh"

MANAGE_WIDGET="$SHORTCUTS_DIR/Manage Apps.sh"
cat > "$MANAGE_WIDGET" << 'MNG_EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME"
bash "$HOME/manage-apps.sh"
MNG_EOF
chmod +x "$MANAGE_WIDGET"
ok "Widget script: ~/.shortcuts/Manage Apps.sh"

THEME_WIDGET="$SHORTCUTS_DIR/Change Theme.sh"
cat > "$THEME_WIDGET" << 'THM_EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME"
bash "$HOME/theme.sh"
THM_EOF
chmod +x "$THEME_WIDGET"
ok "Widget script: ~/.shortcuts/Change Theme.sh"

# ════════════════════════════════════════════════════════════
# Step 8 — Apply default Dark theme
# ════════════════════════════════════════════════════════════
step "Applying default Dark (Dracula) theme"
if [ -f "$HOME/theme.sh" ]; then
    bash "$HOME/theme.sh" --auto dark 2>/dev/null && ok "Dark theme applied" || warn "Theme script not ready yet (run theme.sh after first launch)"
else
    warn "theme.sh not found — theme will be applied on first desktop launch"
fi

# ════════════════════════════════════════════════════════════
# Step 9 — Summary
# ════════════════════════════════════════════════════════════
step "Setup complete"

X11_OK=false; VNC_OK=false; XRDP_OK=false
command -v termux-x11 > /dev/null 2>&1 && X11_OK=true
command -v vncserver  > /dev/null 2>&1 && VNC_OK=true
command -v xrdp       > /dev/null 2>&1 && XRDP_OK=true

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║               📋  Final Summary                ║"
echo "╠══════════════════════════════════════════════════╣"

$X11_OK && echo -e "║  ${GREEN}✓${NC} Mode A — Termux:X11 (recommended) ⚡       ║" \
         || echo -e "║  ${RED}✗${NC} Mode A — termux-x11-nightly missing        ║"

if $VNC_OK && $XRDP_OK; then
    echo -e "║  ${GREEN}✓${NC} Mode B — xRDP WiFi/USB (Windows RDP) 🪟    ║"
elif $VNC_OK || $XRDP_OK; then
    echo -e "║  ${YELLOW}⚠${NC}  Mode B — partial (check VNC + xRDP)       ║"
else
    echo -e "║  ${RED}✗${NC} Mode B — tigervnc + xrdp missing           ║"
fi

echo "╠══════════════════════════════════════════════════╣"
echo "║  Installed apps:                                 ║"
if [ ${#SELECTED_PKGS[@]} -gt 0 ]; then
    for pkg in "${SELECTED_PKGS[@]}"; do
        printf "║    ${GREEN}✓${NC} %-44s║\n" "$pkg"
    done
else
    echo "║    (none selected — run manage-apps.sh later)    ║"
fi
echo "╠══════════════════════════════════════════════════╣"

if [ ${#FAILED_REQUIRED[@]} -gt 0 ]; then
    echo -e "║  ${RED}Failed required packages:${NC}                    ║"
    for p in "${FAILED_REQUIRED[@]}"; do
        printf "║    • %-44s║\n" "$p"
    done
    echo "╠══════════════════════════════════════════════════╣"
fi

echo "║                                                  ║"
echo "║  To start your desktop:                         ║"
echo "║    bash ~/start-desktop.sh                      ║"
echo "║                                                  ║"
echo "║  Other tools:                                    ║"
echo "║    bash ~/manage-apps.sh   ← install more apps  ║"
echo "║    bash ~/theme.sh         ← change theme       ║"
echo "║    bash ~/dashboard.sh     ← system health      ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

[ ${#FAILED_REQUIRED[@]} -gt 0 ] && {
    echo -e "${RED}[!] Some required packages failed. Retry:${NC}"
    echo "    pkg install ${FAILED_REQUIRED[*]}"
    exit 1
}

exit 0
